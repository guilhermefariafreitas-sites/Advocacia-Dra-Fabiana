import { FIRM_INFO, getWhatsAppUrl } from '../lib/contact';
import { FvrLogo } from './FvrLogo';

const FOOTER_LINKS = [
  { label: 'Início', href: '#inicio' },
  { label: 'Biografia', href: '#biografia' },
  { label: 'Áreas de Atuação', href: '#areas' },
  { label: 'Localização', href: '#localizacao' },
  { label: 'Contato', href: '#contato' },
] as const;

export function Footer() {
  return (
    <footer className="border-t border-border-dark bg-marsala py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="flex flex-col justify-between gap-12 border-b border-border-dark pb-12 lg:flex-row lg:items-center">
          <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:gap-10">
            <a
              href="#inicio"
              aria-label={FIRM_INFO.name}
              className="transition-opacity duration-200 hover:opacity-85"
            >
              <FvrLogo variant="full" className="items-start text-left" />
            </a>

            <div className="space-y-1.5 text-sm text-ice-white">
              <p className="font-medium text-pure-white">{FIRM_INFO.oab}</p>
              <p className="max-w-xs leading-relaxed">{FIRM_INFO.address}</p>
              <p className="tabular-nums">
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium text-champagne transition-colors duration-200 hover:text-champagne-hover"
                >
                  WhatsApp: {FIRM_INFO.phoneDisplay}
                </a>
              </p>
            </div>
          </div>

          <nav aria-label="Navegação do rodapé" className="flex flex-wrap gap-x-7 gap-y-3">
            {FOOTER_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-ice-white transition-colors duration-200 hover:text-champagne"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex flex-col justify-between gap-4 pt-8 text-xs text-ice-white/85 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} {FIRM_INFO.fullTitle}. Todos os direitos reservados.</p>
          <p>Atendimento mediante agendamento.</p>
        </div>
      </div>
    </footer>
  );
}
