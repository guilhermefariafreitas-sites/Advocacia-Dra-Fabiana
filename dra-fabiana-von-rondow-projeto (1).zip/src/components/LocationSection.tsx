import { ArrowUpRight, MapPin, Navigation } from 'lucide-react';
import { motion } from 'motion/react';
import {
  FIRM_INFO,
  getGoogleMapsDirectionsUrl,
  getGoogleMapsSearchUrl,
} from '../lib/contact';
import { ResilientImage } from './ResilientImage';

export function LocationSection() {
  return (
    <section
      id="localizacao"
      className="border-b border-border-dark bg-marsala py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center space-y-7 lg:col-span-5"
          >
            <div className="space-y-3">
              <p className="text-sm font-medium tracking-wide text-champagne">
                Atendimento Presencial
              </p>

              <h2
                className="font-display font-medium text-pure-white text-balance leading-[1.08]"
                style={{ fontSize: 'clamp(2rem, 3.6vw, 3.25rem)' }}
              >
                Onde Estamos
              </h2>
            </div>

            <p className="text-base leading-relaxed text-ice-white">
              Recebemos nossos clientes em espaço reservado e acolhedor, preparado para oferecer atendimento personalizado com privacidade e conforto.
            </p>

            <div className="rounded-sm border border-champagne/35 bg-marsala-surface p-6 shadow-sm">
              <div className="flex items-start gap-3.5">
                <MapPin
                  className="mt-0.5 h-5 w-5 shrink-0 text-champagne"
                  strokeWidth={1.75}
                  aria-hidden="true"
                />
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-champagne">
                    Endereço do Escritório
                  </p>
                  <p className="text-base font-medium leading-relaxed text-pure-white">
                    {FIRM_INFO.address}
                  </p>
                  <p className="text-xs text-champagne">
                    {FIRM_INFO.name} · {FIRM_INFO.oab}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3.5 sm:flex-row sm:flex-wrap">
              <a
                href={getGoogleMapsSearchUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 items-center justify-center gap-2.5 rounded-sm border border-champagne/45 bg-marsala-light px-6 py-3 text-sm font-semibold tracking-wide text-pure-white whitespace-nowrap shrink-0 shadow-sm transition-colors duration-200 hover:bg-marsala-light-hover"
              >
                <span>Ver localização no Google Maps</span>
                <ArrowUpRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
              </a>

              <a
                href={getGoogleMapsDirectionsUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 items-center justify-center gap-2.5 rounded-sm border border-champagne/45 bg-marsala-medium px-6 py-3 text-sm font-semibold text-pure-white whitespace-nowrap shrink-0 transition-colors duration-200 hover:bg-marsala-medium-hover"
              >
                <Navigation className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
                <span>Traçar rota até o escritório</span>
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="overflow-hidden rounded-sm border border-champagne/45 bg-marsala-surface p-2.5 shadow-[0_24px_48px_-20px_rgba(32,10,16,0.4)] sm:p-3">
              <ResilientImage
                src="/assets/aistudio/WhatsApp_Image_2026-11-18_at_12.06.36_d476f256.jpeg"
                alt="Fachada oficial do escritório de advocacia Dra. Fabiana Von Rondow — OAB/RO 12627"
                fallbackTitle="Fachada — Dra. Fabiana Von Rondow"
                className="h-auto w-full object-contain"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
