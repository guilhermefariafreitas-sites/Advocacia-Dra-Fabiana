import {
  ArrowUpRight,
  Briefcase,
  Gavel,
  Landmark,
  Leaf,
  MapPin,
  Scale,
  ShieldCheck,
  X,
  type LucideIcon,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import {
  FIRM_INFO,
  getGoogleMapsSearchUrl,
  getWhatsAppUrl,
} from '../lib/contact';
import { FvrMonogram } from './FvrLogo';

interface WhatsAppAreaOption {
  id: string;
  number: string;
  label: string;
  message: string;
  icon: LucideIcon;
}

const WHATSAPP_AREAS: WhatsAppAreaOption[] = [
  {
    id: 'previdenciario',
    number: '1.',
    label: 'Direito Previdenciário',
    message:
      'Olá, Dra. Fabiana! Gostaria de atendimento na área de Direito Previdenciário.',
    icon: Landmark,
  },
  {
    id: 'civil-familia',
    number: '2.',
    label: 'Direito de Família e Sucessões',
    message:
      'Olá, Dra. Fabiana! Gostaria de atendimento na área de Direito de Família e Sucessões.',
    icon: Scale,
  },
  {
    id: 'consumidor',
    number: '3.',
    label: 'Direito do Consumidor',
    message:
      'Olá, Dra. Fabiana! Gostaria de atendimento na área de Direito do Consumidor.',
    icon: ShieldCheck,
  },
  {
    id: 'trabalho',
    number: '4.',
    label: 'Direito do Trabalho',
    message:
      'Olá, Dra. Fabiana! Gostaria de atendimento na área de Direito do Trabalho.',
    icon: Briefcase,
  },
  {
    id: 'ambiental',
    number: '5.',
    label: 'Direito Ambiental',
    message:
      'Olá, Dra. Fabiana! Gostaria de atendimento na área de Direito Ambiental.',
    icon: Leaf,
  },
  {
    id: 'criminal',
    number: '6.',
    label: 'Direito Criminal',
    message:
      'Olá, Dra. Fabiana! Gostaria de atendimento na área de Direito Criminal.',
    icon: Gavel,
  },
];

export function FloatingContactMenu() {
  const [isWhatsAppMenuOpen, setIsWhatsAppMenuOpen] = useState(false);
  const containerRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!isWhatsAppMenuOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsWhatsAppMenuOpen(false);
      }
    };

    const handlePointerDown = (event: MouseEvent | TouchEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsWhatsAppMenuOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('touchstart', handlePointerDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('touchstart', handlePointerDown);
    };
  }, [isWhatsAppMenuOpen]);

  return (
    <aside
      ref={containerRef}
      aria-label="Atalhos flutuantes de contato"
      className="pointer-events-none fixed bottom-5 right-4 z-40 flex flex-col items-end gap-3 sm:bottom-8 sm:right-6"
    >
      <AnimatePresence>
        {isWhatsAppMenuOpen && (
          <motion.div
            id="whatsapp-area-menu"
            role="dialog"
            aria-label="Selecionar área jurídica para atendimento no WhatsApp"
            initial={{ opacity: 0, y: 12, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.97 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="pointer-events-auto fixed bottom-[13.25rem] right-4 z-50 flex max-h-[calc(100svh-14.5rem)] w-[calc(100vw-2rem)] max-w-[365px] flex-col overflow-hidden rounded-md border border-champagne/60 bg-marsala shadow-[0_24px_54px_-14px_rgba(24,6,11,0.58)] sm:bottom-8 sm:right-22 sm:max-h-[calc(100svh-4rem)]"
          >
            <div className="flex items-start justify-between gap-4 border-b border-border-dark bg-marsala-surface px-5 py-4">
              <div className="flex items-center gap-3">
                <FvrMonogram className="h-8 w-8 shrink-0" />
                <div>
                  <p className="font-display text-base font-semibold leading-tight text-pure-white">
                    Dra. Fabiana F. Von Rondow
                  </p>
                  <p className="mt-0.5 text-xs font-medium text-champagne">
                    Atendimento via WhatsApp
                  </p>
                </div>
              </div>

              <button
                type="button"
                aria-label="Fechar menu de áreas"
                onClick={() => setIsWhatsAppMenuOpen(false)}
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border border-transparent text-ice-white transition-colors duration-200 hover:border-champagne/45 hover:bg-marsala-medium hover:text-pure-white"
              >
                <X className="h-4 w-4" strokeWidth={1.75} aria-hidden="true" />
              </button>
            </div>

            <div className="overflow-y-auto px-5 py-4">
              <p className="font-display text-lg font-medium leading-snug text-pure-white">
                Olá! Seja bem-vindo(a). Sobre qual área jurídica você gostaria de receber atendimento?
              </p>

              <ul className="mt-4 space-y-2" role="list">
                {WHATSAPP_AREAS.map((area) => {
                  const Icon = area.icon;
                  return (
                    <li key={area.id}>
                      <a
                        href={getWhatsAppUrl(area.message)}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => setIsWhatsAppMenuOpen(false)}
                        className="group flex min-h-11 items-center justify-between gap-3 rounded-sm border border-champagne/35 bg-marsala-surface px-3.5 py-2.5 text-left transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] hover:border-champagne hover:bg-marsala-medium active:border-champagne"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border border-champagne/45 bg-marsala-medium text-champagne transition-colors duration-200 group-hover:border-champagne group-hover:bg-marsala-light group-hover:text-pure-white">
                            <Icon className="h-4 w-4" strokeWidth={1.7} aria-hidden="true" />
                          </span>
                          <span className="text-sm font-medium leading-snug text-pure-white">
                            <span className="mr-1.5 font-semibold text-champagne tabular-nums">
                              {area.number}
                            </span>
                            {area.label}
                          </span>
                        </div>

                        <ArrowUpRight
                          className="h-4 w-4 shrink-0 text-champagne transition-all duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-pure-white"
                          strokeWidth={1.75}
                          aria-hidden="true"
                        />
                      </a>
                    </li>
                  );
                })}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        type="button"
        onClick={() => setIsWhatsAppMenuOpen((prev) => !prev)}
        aria-expanded={isWhatsAppMenuOpen}
        aria-controls="whatsapp-area-menu"
        aria-label="Abrir opções de atendimento no WhatsApp"
        title={`WhatsApp: ${FIRM_INFO.phoneDisplay}`}
        className={`pointer-events-auto group relative flex h-12 w-12 items-center justify-center rounded-full border shadow-md transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-0.5 hover:shadow-lg sm:h-13 sm:w-13 ${
          isWhatsAppMenuOpen
            ? 'border-[#25D366] bg-[#25D366] text-white'
            : 'border-[#25D366] bg-[#25D366] text-white hover:bg-[#1FB858]'
        }`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="currentColor"
          className="h-6 w-6"
          aria-hidden="true"
        >
          <path d="M12.031 2c-5.516 0-9.969 4.453-9.969 9.969 0 1.766.469 3.484 1.344 5l-1.406 5.156 5.281-1.375c1.469.797 3.109 1.219 4.75 1.219 5.516 0 9.969-4.453 9.969-9.969S17.547 2 12.031 2zm5.813 14.125c-.25.703-1.438 1.344-2 1.422-.516.078-1.172.109-1.891-.125-.438-.141-1-.328-1.719-.641-3.016-1.297-4.984-4.328-5.141-4.531-.141-.203-1.219-1.625-1.219-3.109s.766-2.203 1.047-2.5c.266-.297.594-.375.797-.375s.391 0 .563.016c.188.016.438-.078.672.5.25.609.844 2.063.922 2.219.078.156.125.344.031.547-.109.203-.156.328-.313.516-.156.188-.328.406-.469.547-.156.156-.328.328-.141.641.188.313.844 1.391 1.813 2.25 1.25 1.109 2.297 1.453 2.609 1.609.313.156.5.125.688-.078.188-.203.781-.922.984-1.234.203-.313.406-.266.688-.156.281.109 1.797.844 2.109 1s.516.234.594.359c.078.141.078.797-.172 1.5z" />
        </svg>
        {!isWhatsAppMenuOpen && (
          <span className="pointer-events-none absolute right-14 hidden rounded-md border border-champagne/50 bg-marsala-surface px-3 py-1.5 text-xs font-medium text-pure-white whitespace-nowrap opacity-0 shadow-sm transition-opacity duration-200 group-hover:opacity-100 md:block">
            WhatsApp
          </span>
        )}
      </button>

      <a
        href={FIRM_INFO.instagramUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Instagram oficial da Dra. Fabiana F. Von Rondow"
        title="Instagram Oficial"
        className="pointer-events-auto group relative flex h-12 w-12 items-center justify-center rounded-full border border-transparent bg-[radial-gradient(circle_at_30%_107%,#f58529_0%,#fd5949_34%,#dc2743_52%,#d6249f_74%,#833ab4_100%)] text-white shadow-md transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-0.5 hover:brightness-110 hover:shadow-lg sm:h-13 sm:w-13"
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="h-5 w-5 drop-shadow-[0_1px_1px_rgba(0,0,0,0.2)]"
          aria-hidden="true"
        >
          <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
          <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
        </svg>
        <span className="pointer-events-none absolute right-14 hidden rounded-md border border-champagne/50 bg-marsala-surface px-3 py-1.5 text-xs font-medium text-pure-white whitespace-nowrap opacity-0 shadow-sm transition-opacity duration-200 group-hover:opacity-100 md:block">
          Instagram
        </span>
      </a>

      <a
        href={getGoogleMapsSearchUrl()}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Ver localização do escritório no Google Maps"
        title="Localização no Google Maps"
        className="pointer-events-auto group relative flex h-12 w-12 items-center justify-center rounded-full border border-[#EA4335] bg-[#EA4335] text-white shadow-md transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-0.5 hover:border-[#D93025] hover:bg-[#D93025] hover:shadow-lg sm:h-13 sm:w-13"
      >
        <MapPin className="h-5 w-5 drop-shadow-[0_1px_1px_rgba(0,0,0,0.18)]" strokeWidth={2} aria-hidden="true" />
        <span className="pointer-events-none absolute right-14 hidden rounded-md border border-champagne/50 bg-marsala-surface px-3 py-1.5 text-xs font-medium text-pure-white whitespace-nowrap opacity-0 shadow-sm transition-opacity duration-200 group-hover:opacity-100 md:block">
          Localização
        </span>
      </a>
    </aside>
  );
}
