import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { FIRM_INFO, getWhatsAppUrl } from '../lib/contact';
import { FvrMonogram } from './FvrLogo';
import { ResilientImage } from './ResilientImage';

export function HeroSection() {
  const whatsappHref = getWhatsAppUrl();

  return (
    <section
      id="inicio"
      className="relative border-b border-border-dark bg-marsala pt-24 pb-16 sm:pt-28 sm:pb-20 lg:min-h-[calc(100svh-4rem)] lg:pt-28 lg:pb-16 flex items-center"
    >
      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-14">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between py-2 lg:col-span-6 lg:py-4"
          >
            <div className="space-y-6">
              <div className="flex items-center gap-3.5">
                <FvrMonogram className="h-10 w-10 shrink-0" />
                <div>
                  <p className="font-display text-lg font-medium text-pure-white">
                    {FIRM_INFO.name}
                  </p>
                  <p className="text-xs font-medium tracking-wider text-champagne">
                    {FIRM_INFO.tagline} · {FIRM_INFO.oab}
                  </p>
                </div>
              </div>

              <h1
                className="font-display font-medium tracking-tight text-pure-white text-balance leading-[1.08]"
                style={{ fontSize: 'clamp(1.65rem, 3.2vw, 3.1rem)' }}
              >
                ATENDIMENTO HUMANIZADO. RIGOR TÉCNICO-JURÍDICO E RESPONSABILIDADE.
              </h1>

              <div className="max-w-xl space-y-3">
                <p className="text-xs font-semibold tracking-[0.14em] text-champagne sm:text-sm">
                  FOCO EM ÉTICA, CONFIANÇA E TRADIÇÃO
                </p>
                <ul className="space-y-2 text-sm leading-relaxed text-ice-white sm:text-base">
                  <li className="flex items-start gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-champagne" aria-hidden="true" />
                    <span>Compromisso técnico com a defesa de direitos.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-champagne" aria-hidden="true" />
                    <span>Atuação pautada na ética, transparência e rigor jurídico.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-champagne" aria-hidden="true" />
                    <span>Orientação jurídica clara para decisões seguras.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-champagne" aria-hidden="true" />
                    <span>Onde cada caso recebe atenção técnica e individualizada.</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-10 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:gap-5 lg:mt-14">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 items-center justify-center gap-3 rounded-sm border border-champagne/45 bg-marsala-light px-7 py-3.5 text-sm font-semibold tracking-wide text-pure-white whitespace-nowrap shrink-0 shadow-sm transition-colors duration-200 hover:bg-marsala-light-hover"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
              </a>

              <a
                href="#areas"
                className="inline-flex min-h-12 items-center justify-center gap-2.5 rounded-sm border border-champagne/40 bg-marsala-medium px-6 py-3.5 text-sm font-semibold text-pure-white whitespace-nowrap shrink-0 transition-colors duration-200 hover:bg-marsala-medium-hover"
              >
                <span>Conhecer áreas de atuação</span>
                <ArrowDownRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.5} aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.985 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.65, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-6"
          >
            <div className="overflow-hidden rounded-sm border border-champagne/45 bg-marsala-surface p-2 shadow-[0_24px_50px_-20px_rgba(32,10,16,0.4)] sm:p-3">
              <div className="overflow-hidden">
                <ResilientImage
                  src="/assets/aistudio/WhatsApp_Image_2026-11-17_at_15.37.44__1__b6996b51.jpeg"
                  alt="Placa oficial dourada FVR — Dra. Fabiana F. Von Rondow, Assessoria e Consultoria Jurídica"
                  loading="eager"
                  className="h-auto w-full object-cover"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
