import { ArrowUpRight, Check, Download, Loader2, Menu, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { getWhatsAppUrl } from '../lib/contact';
import { FvrLogo } from './FvrLogo';

const PROJECT_ZIP_FILENAME = 'dra-fabiana-von-rondow-projeto.zip';

const NAV_LINKS = [
  { label: 'Início', href: '#inicio' },
  { label: 'Biografia', href: '#biografia' },
  { label: 'Áreas de Atuação', href: '#areas' },
  { label: 'Localização', href: '#localizacao' },
  { label: 'Contato', href: '#contato' },
] as const;

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [zipStatus, setZipStatus] = useState<'idle' | 'downloading' | 'done'>('idle');

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleDownloadProjectZip = async () => {
    if (zipStatus === 'downloading') return;
    setZipStatus('downloading');

    try {
      const response = await fetch(`/${PROJECT_ZIP_FILENAME}`, { cache: 'no-store' });
      if (!response.ok) {
        throw new Error('Falha ao gerar ZIP');
      }
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = objectUrl;
      anchor.download = PROJECT_ZIP_FILENAME;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
      setZipStatus('done');
    } catch {
      const fallbackAnchor = document.createElement('a');
      fallbackAnchor.href = `/${PROJECT_ZIP_FILENAME}`;
      fallbackAnchor.download = PROJECT_ZIP_FILENAME;
      document.body.appendChild(fallbackAnchor);
      fallbackAnchor.click();
      fallbackAnchor.remove();
      setZipStatus('done');
    } finally {
      setTimeout(() => {
        setZipStatus((current) => (current === 'done' ? 'idle' : current));
      }, 2500);
    }
  };

  const whatsappHref = getWhatsAppUrl();

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border-dark bg-marsala/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 sm:px-8 lg:px-12 xl:gap-8">
        <div className="flex min-w-0 shrink-0 items-center gap-2 sm:gap-2.5">
          <a
            href="#inicio"
            aria-label="Início — Dra. Fabiana F. Von Rondow"
            className="shrink-0 transition-opacity duration-200 hover:opacity-85"
          >
            <FvrLogo variant="header" />
          </a>

          <button
            type="button"
            onClick={handleDownloadProjectZip}
            disabled={zipStatus === 'downloading'}
            aria-label="Baixar arquivo ZIP do projeto para o GitHub"
            title="Baixar projeto em .zip para enviar ao GitHub"
            className="group relative inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border border-champagne/45 bg-marsala-surface text-champagne shadow-sm transition-colors duration-200 hover:border-champagne hover:bg-marsala-light hover:text-pure-white disabled:cursor-wait disabled:opacity-80 sm:h-9 sm:w-9"
          >
            {zipStatus === 'downloading' ? (
              <Loader2 className="h-4 w-4 animate-spin" strokeWidth={1.85} aria-hidden="true" />
            ) : zipStatus === 'done' ? (
              <Check className="h-4 w-4 text-success" strokeWidth={2} aria-hidden="true" />
            ) : (
              <Download className="h-4 w-4" strokeWidth={1.85} aria-hidden="true" />
            )}
            <span className="pointer-events-none absolute top-full left-1/2 mt-2 hidden -translate-x-1/2 rounded-sm border border-champagne/50 bg-marsala-surface px-2.5 py-1 text-[11px] font-medium text-pure-white whitespace-nowrap opacity-0 shadow-md transition-opacity duration-200 group-hover:opacity-100 md:block">
              {zipStatus === 'done' ? 'Projeto baixado (.zip)' : 'Baixar projeto (.zip)'}
            </span>
          </button>
        </div>

        <nav aria-label="Navegação principal" className="hidden items-center gap-5 lg:flex xl:gap-7">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 text-sm font-medium text-ice-white whitespace-nowrap shrink-0 transition-colors duration-200 hover:text-champagne after:absolute after:inset-x-0 after:bottom-0 after:h-px after:origin-left after:scale-x-0 after:bg-champagne after:transition-transform after:duration-200 hover:after:scale-x-100"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden lg:inline-flex items-center gap-2 rounded-sm border border-champagne/45 bg-marsala-light px-5 py-2.5 text-xs font-semibold tracking-wide text-pure-white whitespace-nowrap shrink-0 shadow-sm transition-colors duration-200 hover:bg-marsala-light-hover"
          >
            <span>Conversar no WhatsApp</span>
            <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
          </a>

          <button
            type="button"
            aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            onClick={() => setMenuOpen((prev) => !prev)}
            className="inline-flex h-11 w-11 items-center justify-center rounded-sm border border-champagne/40 bg-marsala-medium text-pure-white transition-colors duration-200 hover:bg-marsala-light lg:hidden"
          >
            {menuOpen ? (
              <X className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            id="mobile-nav"
            aria-label="Navegação móvel"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="border-b border-border-dark bg-marsala px-5 pb-6 pt-4 shadow-lg lg:hidden"
          >
            <div className="flex flex-col divide-y divide-border-dark">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className="py-3.5 text-base font-medium text-ice-white transition-colors duration-200 hover:text-champagne"
                >
                  {link.label}
                </a>
              ))}
            </div>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMenuOpen(false)}
              className="mt-5 flex min-h-11 w-full items-center justify-center gap-2 rounded-sm border border-champagne/45 bg-marsala-light px-5 py-3 text-sm font-semibold tracking-wide text-pure-white transition-colors duration-200 hover:bg-marsala-light-hover"
            >
              <span>Conversar no WhatsApp</span>
              <ArrowUpRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
            </a>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
