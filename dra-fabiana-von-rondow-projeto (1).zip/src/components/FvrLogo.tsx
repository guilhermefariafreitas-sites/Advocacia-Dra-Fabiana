import { useId } from 'react';
import { FIRM_INFO } from '../lib/contact';

interface FvrLogoProps {
  variant?: 'header' | 'full';
  className?: string;
}

export function FvrMonogram({ className = 'h-10 w-10' }: { className?: string }) {
  const gradientId = useId();

  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className={className}
    >
      <defs>
        <linearGradient id={gradientId} x1="12" y1="12" x2="108" y2="108" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#EADBC5" />
          <stop offset="50%" stopColor="#D8C3A5" />
          <stop offset="100%" stopColor="#BCA07A" />
        </linearGradient>
      </defs>

      {/* Moldura em L aberto inferior esquerdo e superior direito, fiel à placa oficial */}
      <path
        d="M16 30V104H76"
        stroke={`url(#${gradientId})`}
        strokeWidth="3.2"
        strokeLinecap="square"
      />
      <path
        d="M36 16H104V86"
        stroke={`url(#${gradientId})`}
        strokeWidth="3.2"
        strokeLinecap="square"
      />

      {/* Monograma entrelaçado F V R */}
      <path
        d="M33 84V36H56M33 57H51"
        stroke={`url(#${gradientId})`}
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M44 36L60 88L76 36"
        stroke={`url(#${gradientId})`}
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M72 36H84C92 36 96 41 96 48C96 55 92 60 84 60H70M78 60L95 88"
        stroke={`url(#${gradientId})`}
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function FvrLogo({ variant = 'header', className = '' }: FvrLogoProps) {
  if (variant === 'full') {
    return (
      <div className={`inline-flex flex-col items-center text-center ${className}`}>
        <FvrMonogram className="h-20 w-20 sm:h-24 sm:w-24" />
        <div className="mt-4 w-full">
          <p className="font-display text-2xl font-medium tracking-wide text-pure-white sm:text-3xl">
            {FIRM_INFO.name}
          </p>
          <div className="mx-auto my-2 h-px w-full max-w-[290px] bg-gradient-to-r from-transparent via-champagne to-transparent" />
          <p className="text-[11px] font-medium tracking-[0.22em] text-champagne uppercase">
            {FIRM_INFO.tagline}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center gap-2 sm:gap-3 ${className}`}>
      <FvrMonogram className="h-8 w-8 shrink-0 sm:h-10 sm:w-10" />
      <span className="font-display text-base font-semibold tracking-wide text-pure-white whitespace-nowrap sm:text-xl">
        {FIRM_INFO.name}
      </span>
    </div>
  );
}
