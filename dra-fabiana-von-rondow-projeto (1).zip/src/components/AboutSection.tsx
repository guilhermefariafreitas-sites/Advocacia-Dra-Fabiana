import { motion } from 'motion/react';
import { FIRM_INFO } from '../lib/contact';
import { ResilientImage } from './ResilientImage';

export function AboutSection() {
  return (
    <section id="biografia" className="border-b border-border-dark bg-marsala py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="mx-auto max-w-md overflow-hidden rounded-sm border border-champagne/45 bg-marsala-surface p-2.5 shadow-[0_24px_50px_-20px_rgba(32,10,16,0.4)] sm:p-3 lg:max-w-none">
              <ResilientImage
                src="/assets/aistudio/WhatsApp_Image_2026-11-17_at_15.37.44_2886ea29.jpeg"
                alt="Fotografia profissional da Dra. Fabiana F. Von Rondow em seu escritório de advocacia"
                fallbackTitle={FIRM_INFO.name}
                className="h-auto w-full object-contain"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center space-y-7 lg:col-span-7"
          >
            <div className="space-y-3">
              <p className="text-sm font-medium tracking-wide text-champagne">
                Sobre a Advogada
              </p>

              <h2
                className="font-display font-medium text-pure-white text-balance leading-[1.1]"
                style={{ fontSize: 'clamp(2rem, 3.6vw, 3.25rem)' }}
              >
                Uma trajetória guiada pelo conhecimento e pela justiça
              </h2>
            </div>

            <div className="h-px w-20 bg-champagne/75" aria-hidden="true" />

            <div className="space-y-4 text-base leading-relaxed text-ice-white sm:text-[1.0625rem]">
              <p>
                Muito prazer! Sou advogada especialista em Direito Previdenciário e apaixonada pelo Direito Sucessório, mas a minha história com a proteção de direitos e do patrimônio familiar começou muito antes da OAB.
              </p>

              <p>
                Antes de realizar o grande sonho de me tornar advogada — formada em Direito pela FAAR em Ariquemes (2022) —, construí uma base como Contadora (formada pela FIAR em 2013, com pós-graduação em Auditoria e Perícia Contábil) e atuei por 5 anos no serviço público. Essa bagagem dupla me permite olhar para cada caso não apenas com rigor jurídico, mas com precisão nos encargos tributários que recaem ao contribuinte, na análise documental e no entendimento de como funciona a administração pública e suas exigências burocráticas.
              </p>

              <p>
                Fora do escritório, sou esposa há duas décadas e mãe de dois lindos filhos, Débora e Davi, minha razão de viver.
              </p>

              <p>
                É justamente essa vivência familiar que guia o meu atendimento: acredito em uma advocacia próxima, transparente e feita com amor, cuidando com cada pedido de benefício e do legado de cada cliente como se fosse da minha própria família.
              </p>

              <p>
                Nas horas vagas, recarrego as energias planejando viagens, conhecer novos lugares e pessoas — e carrego comigo o grande sonho de um dia explorar as estradas de motorhome.
              </p>

              <p className="font-medium text-champagne">
                Bem vindo!
              </p>
            </div>

            <div className="border-t border-border-dark pt-6">
              <p className="font-display text-xl font-medium text-pure-white">
                {FIRM_INFO.name}
              </p>
              <p className="mt-1 text-sm text-champagne">
                {FIRM_INFO.tagline} · {FIRM_INFO.oab}
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
