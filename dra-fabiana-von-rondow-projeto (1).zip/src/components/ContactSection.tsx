import { AlertCircle, ArrowUpRight, CheckCircle2, MapPin, Phone } from 'lucide-react';
import { motion } from 'motion/react';
import { FormEvent, useState } from 'react';
import { FIRM_INFO, getWhatsAppUrl } from '../lib/contact';

interface FormErrors {
  name?: string;
  phone?: string;
  message?: string;
}

const AREAS_OPTIONS = [
  'Direito Previdenciário',
  'Direito de Família e Sucessões',
  'Direito do Consumidor',
  'Direito do Trabalho',
  'Direito Ambiental',
  'Direito Criminal',
  'Outro assunto jurídico',
] as const;

export function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [area, setArea] = useState<string>(AREAS_OPTIONS[0]);
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 10) {
      nextErrors.phone = 'Informe um telefone ou WhatsApp válido com DDD.';
    }
    if (message.trim().length < 8) {
      nextErrors.message = 'Descreva brevemente sua necessidade jurídica.';
    }
    return nextErrors;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);

    if (Object.keys(validation).length > 0) {
      return;
    }

    const composed = [
      `Olá, ${FIRM_INFO.name}.`,
      `Nome: ${name.trim()}`,
      `Telefone: ${phone.trim()}`,
      `Área: ${area}`,
      `Resumo: ${message.trim()}`,
    ].join('\n');

    const url = getWhatsAppUrl(composed);
    setSubmittedUrl(url);

    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    anchor.click();
  };

  const handleReset = () => {
    setSubmittedUrl(null);
    setName('');
    setPhone('');
    setArea(AREAS_OPTIONS[0]);
    setMessage('');
    setErrors({});
  };

  return (
    <section id="contato" className="bg-marsala py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-stretch gap-14 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between space-y-10 lg:col-span-5"
          >
            <div className="space-y-5">
              <p className="text-sm font-medium tracking-wide text-champagne">
                Atendimento
              </p>

              <h2
                className="font-display font-medium text-pure-white text-balance leading-[1.08]"
                style={{ fontSize: 'clamp(2rem, 3.6vw, 3.25rem)' }}
              >
                Converse diretamente com o escritório.
              </h2>

              <p className="text-base leading-relaxed text-ice-white">
                Agende sua consulta pelo WhatsApp ou preencha o formulário ao lado para agilizar seu atendimento jurídico.
              </p>
            </div>

            <div className="space-y-4 border-t border-border-dark pt-8">
              <div className="flex items-start gap-4 rounded-sm border border-champagne/65 bg-marsala-light p-4">
                <MapPin
                  className="mt-0.5 h-4 w-4 shrink-0 text-champagne"
                  strokeWidth={1.75}
                  aria-hidden="true"
                />
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-champagne">
                    Endereço
                  </p>
                  <p className="text-sm leading-relaxed text-pure-white">
                    {FIRM_INFO.address}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-sm border border-champagne/65 bg-marsala-light p-4">
                <Phone
                  className="mt-0.5 h-4 w-4 shrink-0 text-champagne"
                  strokeWidth={1.75}
                  aria-hidden="true"
                />
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-champagne">
                    Telefone e WhatsApp
                  </p>
                  <a
                    href={`tel:+${FIRM_INFO.phoneRaw}`}
                    className="inline-block text-sm font-medium text-pure-white tabular-nums transition-colors duration-200 hover:text-champagne"
                  >
                    {FIRM_INFO.phoneDisplay}
                  </a>
                </div>
              </div>

              <div className="pt-2">
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-12 items-center justify-center gap-3 rounded-sm border border-champagne/45 bg-marsala-light px-7 py-3.5 text-sm font-semibold tracking-wide text-pure-white whitespace-nowrap shrink-0 shadow-sm transition-colors duration-200 hover:bg-marsala-light-hover"
                >
                  <span>Conversar no WhatsApp</span>
                  <ArrowUpRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-sm border border-champagne/35 bg-marsala-surface p-6 shadow-[0_24px_50px_-20px_rgba(24,6,11,0.42)] sm:p-10 lg:col-span-7"
          >
            {submittedUrl ? (
              <div className="flex h-full flex-col justify-between space-y-8 py-4">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2.5 rounded-sm bg-success-surface px-3.5 py-2 text-xs font-medium text-success">
                    <CheckCircle2 className="h-4 w-4 shrink-0" strokeWidth={1.75} aria-hidden="true" />
                    <span>Solicitação pronta para envio</span>
                  </div>
                  <h3 className="font-display text-3xl font-medium text-pure-white">
                    Atendimento iniciado via WhatsApp.
                  </h3>
                  <p className="max-w-lg text-sm leading-relaxed text-ice-white">
                    Se a nova aba não abriu automaticamente no seu navegador, clique no botão abaixo para encaminhar os dados diretamente à {FIRM_INFO.name}.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-4 border-t border-border-dark pt-6">
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-champagne/45 bg-marsala-light px-6 py-3 text-sm font-semibold tracking-wide text-pure-white whitespace-nowrap shrink-0 transition-colors duration-200 hover:bg-marsala-light-hover"
                  >
                    <span>Abrir WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={handleReset}
                    className="min-h-11 rounded-sm border border-champagne/40 bg-marsala-medium px-5 py-3 text-sm font-medium text-pure-white transition-colors duration-200 hover:bg-marsala-medium-hover"
                  >
                    Nova mensagem
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label
                      htmlFor="contact-name"
                      className="block text-xs font-semibold text-champagne"
                    >
                      Nome completo
                    </label>
                    <input
                      id="contact-name"
                      name="name"
                      type="text"
                      autoComplete="name"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                      }}
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? 'error-name' : undefined}
                      placeholder="Seu nome completo"
                      className="min-h-11 w-full rounded-sm border border-champagne/65 bg-marsala-light px-4 py-3 text-sm text-pure-white placeholder:text-ice-white/85 transition-colors duration-200 focus:border-champagne focus:outline-none"
                    />
                    {errors.name && (
                      <p
                        id="error-name"
                        role="alert"
                        className="flex items-center gap-1.5 text-xs text-error"
                      >
                        <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.name}</span>
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="contact-phone"
                      className="block text-xs font-semibold text-champagne"
                    >
                      Telefone ou WhatsApp
                    </label>
                    <input
                      id="contact-phone"
                      name="phone"
                      type="tel"
                      autoComplete="tel"
                      value={phone}
                      onChange={(e) => {
                        setPhone(e.target.value);
                        if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                      }}
                      aria-invalid={Boolean(errors.phone)}
                      aria-describedby={errors.phone ? 'error-phone' : undefined}
                      placeholder="(69) 99999-9999"
                      className="min-h-11 w-full rounded-sm border border-champagne/65 bg-marsala-light px-4 py-3 text-sm text-pure-white tabular-nums placeholder:text-ice-white/85 transition-colors duration-200 focus:border-champagne focus:outline-none"
                    />
                    {errors.phone && (
                      <p
                        id="error-phone"
                        role="alert"
                        className="flex items-center gap-1.5 text-xs text-error"
                      >
                        <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.phone}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="contact-area"
                    className="block text-xs font-semibold text-champagne"
                  >
                    Área de interesse
                  </label>
                  <select
                    id="contact-area"
                    name="area"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="min-h-11 w-full rounded-sm border border-champagne/65 bg-marsala-light px-4 py-3 text-sm text-pure-white transition-colors duration-200 focus:border-champagne focus:outline-none"
                  >
                    {AREAS_OPTIONS.map((option) => (
                      <option key={option} value={option} className="bg-marsala text-pure-white">
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-semibold text-champagne"
                  >
                    Breve relato do caso
                  </label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows={4}
                    value={message}
                    onChange={(e) => {
                      setMessage(e.target.value);
                      if (errors.message) setErrors((prev) => ({ ...prev, message: undefined }));
                    }}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'error-message' : undefined}
                    placeholder="Descreva em poucas linhas como podemos auxiliar."
                    className="w-full resize-none rounded-sm border border-champagne/65 bg-marsala-light px-4 py-3 text-sm text-pure-white placeholder:text-ice-white/85 transition-colors duration-200 focus:border-champagne focus:outline-none"
                  />
                  {errors.message && (
                    <p
                      id="error-message"
                      role="alert"
                      className="flex items-center gap-1.5 text-xs text-error"
                    >
                      <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      <span>{errors.message}</span>
                    </p>
                  )}
                </div>

                <div className="flex flex-col justify-between gap-4 pt-2 sm:flex-row sm:items-center">
                  <p className="text-xs text-ice-white/85">
                    Atendimento sigiloso encaminhado diretamente pelo WhatsApp.
                  </p>
                  <button
                    type="submit"
                    className="inline-flex min-h-12 items-center justify-center gap-2.5 rounded-sm border border-champagne/45 bg-marsala-light px-7 py-3.5 text-sm font-semibold tracking-wide text-pure-white whitespace-nowrap shrink-0 shadow-sm transition-colors duration-200 hover:bg-marsala-light-hover"
                  >
                    <span>Conversar no WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4 shrink-0 text-champagne" strokeWidth={1.75} aria-hidden="true" />
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
