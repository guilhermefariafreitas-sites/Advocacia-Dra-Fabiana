import {
  ArrowUpRight,
  Briefcase,
  Gavel,
  Landmark,
  Leaf,
  Scale,
  ShieldCheck,
  type LucideIcon,
} from 'lucide-react';
import { motion } from 'motion/react';
import { getWhatsAppUrl } from '../lib/contact';

interface PracticeArea {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
}

const PRACTICE_AREAS: PracticeArea[] = [
  {
    id: 'previdenciario',
    title: 'Direito Previdenciário',
    description:
      'Atuação voltada à garantia dos direitos dos segurados e beneficiários da Previdência Social. Abrange questões relacionadas à aposentadoria, benefícios por incapacidade, auxílio-doença, pensão por morte, benefícios assistenciais e revisões previdenciárias.',
    icon: Landmark,
  },
  {
    id: 'civil-familia',
    title: 'Direito de Família e Sucessões',
    description:
      'Atuação na resolução de conflitos e questões relacionadas às relações civis e familiares. Abrange demandas envolvendo contratos, direitos e obrigações, divórcios, pensão alimentícia, guarda de filhos e regulamentação de visitas, buscando soluções adequadas para cada situação.',
    icon: Scale,
  },
  {
    id: 'consumidor',
    title: 'Direito do Consumidor',
    description:
      'Defesa dos direitos dos consumidores diante de práticas abusivas e irregularidades nas relações de consumo. Abrange questões envolvendo cobranças indevidas, negativação indevida, problemas com produtos e serviços, contratos e falhas na prestação de serviços.',
    icon: ShieldCheck,
  },
  {
    id: 'trabalho',
    title: 'Direito do Trabalho',
    description:
      'Atuação na defesa dos direitos e interesses nas relações trabalhistas, envolvendo empregados e empregadores. Abrange questões relacionadas a verbas rescisórias, horas extras, reconhecimento de vínculo empregatício, férias, FGTS e outras demandas trabalhistas.',
    icon: Briefcase,
  },
  {
    id: 'ambiental',
    title: 'Direito Ambiental',
    description:
      'Atuação em questões jurídicas relacionadas à proteção do meio ambiente e ao cumprimento da legislação ambiental. Abrange conflitos ambientais, responsabilidades por danos ambientais, licenciamento, infrações e questões administrativas relacionadas ao meio ambiente.',
    icon: Leaf,
  },
  {
    id: 'criminal',
    title: 'Direito Criminal',
    description:
      'Atuação na defesa dos direitos e garantias fundamentais em investigações e processos criminais. Inclui acompanhamento jurídico em procedimentos policiais, audiências e ações penais, buscando assegurar o devido processo legal e o direito à ampla defesa.',
    icon: Gavel,
  },
];

export function PracticeAreasSection() {
  return (
    <section id="areas" className="border-b border-border-dark bg-marsala py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="mb-14 flex flex-col justify-between gap-6 border-b border-border-dark pb-10 lg:flex-row lg:items-end"
        >
          <div className="space-y-3">
            <p className="text-sm font-medium tracking-wide text-champagne">
              Especialidades Jurídicas
            </p>
            <h2
              className="font-display font-medium text-pure-white text-balance leading-[1.08]"
              style={{ fontSize: 'clamp(2rem, 3.6vw, 3.25rem)' }}
            >
              Áreas de Atuação
            </h2>
          </div>

          <p className="max-w-md text-sm leading-relaxed text-ice-white sm:text-base">
            Atendimento técnico, ético e personalizado nas principais frentes jurídicas para proteger seus direitos.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          {PRACTICE_AREAS.map((area, index) => {
            const Icon = area.icon;
            return (
              <motion.article
                key={area.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.05,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="group flex flex-col justify-between rounded-lg border border-champagne/60 bg-marsala-light p-7 shadow-[0_14px_34px_-16px_rgba(24,6,11,0.42)] transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-1.5 hover:border-champagne hover:bg-marsala-light-hover hover:shadow-[0_24px_48px_-14px_rgba(24,6,11,0.52)] active:-translate-y-1 active:border-champagne sm:p-8"
              >
                <div className="space-y-5">
                  <div className="inline-flex h-12 w-12 items-center justify-center rounded-md border border-champagne/65 bg-marsala text-champagne transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-105 group-hover:border-champagne group-hover:text-pure-white">
                    <Icon
                      className="h-5 w-5 transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:rotate-[-4deg]"
                      strokeWidth={1.75}
                      aria-hidden="true"
                    />
                  </div>

                  <h3 className="font-display text-2xl font-semibold text-pure-white">
                    {area.title}
                  </h3>

                  <p className="text-sm leading-relaxed text-ice-white">
                    {area.description}
                  </p>
                </div>

                <div className="mt-8 border-t border-champagne/50 pt-5">
                  <a
                    href={getWhatsAppUrl(
                      `Olá, Dra. Fabiana F. Von Rondow. Gostaria de orientação jurídica em ${area.title}.`,
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-10 items-center gap-2 rounded-md border border-champagne/60 bg-marsala px-4 py-2 text-sm font-semibold text-pure-white transition-colors duration-300 hover:border-champagne hover:bg-marsala-medium"
                  >
                    <span>Falar sobre {area.title}</span>
                    <ArrowUpRight
                      className="h-4 w-4 shrink-0 text-champagne transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                      strokeWidth={1.75}
                      aria-hidden="true"
                    />
                  </a>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
