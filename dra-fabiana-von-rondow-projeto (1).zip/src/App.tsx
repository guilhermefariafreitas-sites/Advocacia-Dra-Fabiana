import { MotionConfig } from 'motion/react';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { FloatingContactMenu } from './components/FloatingContactMenu';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { LocationSection } from './components/LocationSection';
import { Navbar } from './components/Navbar';
import { PracticeAreasSection } from './components/PracticeAreasSection';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-marsala text-pure-white">
        <a
          href="#conteudo-principal"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:bg-champagne focus:px-4 focus:py-2 focus:text-xs focus:font-semibold focus:text-wine-ink"
        >
          Ir para o conteúdo principal
        </a>
        <Navbar />
        <main id="conteudo-principal">
          <HeroSection />
          <AboutSection />
          <PracticeAreasSection />
          <LocationSection />
          <ContactSection />
        </main>
        <FloatingContactMenu />
        <Footer />
      </div>
    </MotionConfig>
  );
}
