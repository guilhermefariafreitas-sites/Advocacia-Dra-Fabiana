export const FIRM_INFO = {
  name: 'Dra. Fabiana F. Von Rondow',
  fullTitle: 'Dra. Fabiana F. Von Rondow — Assessoria e Consultoria Jurídica',
  tagline: 'Assessoria e Consultoria Jurídica',
  oab: 'OAB/RO 12627',
  address: 'Rua Ursa Maior, N 4841, Bairro Rota do Sol, CEP: 76.874-042',
  phoneDisplay: '(69) 9 9936-4242',
  phoneRaw: '5569999364242',
  instagramUrl: 'https://www.instagram.com/dra_fabianavonrondow/',
  defaultWhatsAppMessage:
    'Olá, Dra. Fabiana F. Von Rondow. Gostaria de agendar um atendimento jurídico.',
} as const;

export function getWhatsAppUrl(customMessage?: string): string {
  const message = encodeURIComponent(
    customMessage?.trim() || FIRM_INFO.defaultWhatsAppMessage,
  );
  return `https://wa.me/${FIRM_INFO.phoneRaw}?text=${message}`;
}

export function getGoogleMapsSearchUrl(): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(FIRM_INFO.address)}`;
}

export function getGoogleMapsDirectionsUrl(): string {
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(FIRM_INFO.address)}`;
}
