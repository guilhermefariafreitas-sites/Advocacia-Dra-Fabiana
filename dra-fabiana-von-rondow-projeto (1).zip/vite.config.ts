import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import {defineConfig, type Plugin} from 'vite';

const PROJECT_ZIP_FILENAME = 'dra-fabiana-von-rondow-projeto.zip';
const IGNORED_DIRS = new Set([
  'node_modules',
  'dist',
  'build',
  '.git',
  '.aistudio',
  'coverage',
]);

function collectProjectFiles(dir: string, rootDir: string, zip: JSZip): void {
  const entries = fs.readdirSync(dir, {withFileTypes: true});

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relativePath = path.relative(rootDir, fullPath).split(path.sep).join('/');

    if (entry.isDirectory()) {
      if (!IGNORED_DIRS.has(entry.name)) {
        collectProjectFiles(fullPath, rootDir, zip);
      }
      continue;
    }

    if (!entry.isFile()) continue;
    if (entry.name === '.DS_Store' || entry.name.endsWith('.log') || entry.name.endsWith('.zip')) {
      continue;
    }
    if (entry.name.startsWith('.env') && entry.name !== '.env.example') {
      continue;
    }

    zip.file(relativePath, fs.readFileSync(fullPath));
  }
}

async function createProjectZipBuffer(rootDir: string): Promise<Buffer> {
  const zip = new JSZip();
  collectProjectFiles(rootDir, rootDir, zip);
  return zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: {level: 6},
  });
}

function projectZipPlugin(rootDir: string): Plugin {
  return {
    name: 'project-zip-download',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const requestPath = req.url?.split('?')[0];
        if (req.method !== 'GET' || requestPath !== `/${PROJECT_ZIP_FILENAME}`) {
          next();
          return;
        }

        try {
          const buffer = await createProjectZipBuffer(rootDir);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/zip');
          res.setHeader(
            'Content-Disposition',
            `attachment; filename="${PROJECT_ZIP_FILENAME}"`,
          );
          res.setHeader('Content-Length', String(buffer.length));
          res.setHeader('Cache-Control', 'no-store');
          res.end(buffer);
        } catch (err) {
          next(err instanceof Error ? err : new Error('Failed to generate project zip'));
        }
      });
    },
    async closeBundle(error?: Error): Promise<void> {
      if (error) {
        return;
      }
      const distDir = path.resolve(rootDir, 'dist');
      if (!fs.existsSync(distDir)) {
        return;
      }
      const buffer = await createProjectZipBuffer(rootDir);
      fs.writeFileSync(path.join(distDir, PROJECT_ZIP_FILENAME), buffer);
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      projectZipPlugin(__dirname),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
